import fresh_tomatoes
import media

toy_story = media.Movie("Toy Story","A story of a boy and his toys that come to life",
                        "https://imgc.allpostersimages.com/img/print/posters/toy-story-woody-buzz_a-G-13390941-0.jpg",
                        "https://www.youtube.com/watch?v=KYz2wyBy3kc")
#print (toy_story.storyline)

avatar = media.Movie("Avatar","A marine on an alien planet",
                     "https://http2.mlstatic.com/poster-original-avatar-60-x-90-cm-D_NQ_NP_13835-MLB4594260504_072013-F.jpg",
                     "https://www.youtube.com/watch?v=5PSNL1qE6VY")
#print (avatar.storyline)
#avatar.show_trailer()

black_swan = media.Movie("Black Swan","A dancer whose obsession with dance overcomes all facets of her life",
                         "https://assetsgn.nowonline.com.br/assets/p8236892_v_v8_ad.jpg?api_key=snfwq54bnzvgucd7cqvgt86r&h=undefined",
                         "https://www.youtube.com/watch?v=5jaI1XOB-bs")
#black_swan.show_trailer()

interestelar = media.Movie("Interestelar","Group of astronauts receives a mission to check possible planets to receive the world population",
                           "http://poseseneuroses.com.br/wordpress/wp-content/uploads/2016/02/Interestelar-Poster.png",
                           "https://www.youtube.com/watch?v=zSWdZVtXT7E")

baby_driver = media.Movie("Baby Driver","The talented escape driver Baby relies on the beats from his own soundtrack to be the best there is",
                          "https://i.pinimg.com/originals/25/0b/8a/250b8ad47d92ba9d7d6ffeaee380afed.jpg",
                          "https://www.youtube.com/watch?v=z2z857RSfhk")

fantastic_beasts = media.Movie("Fantastic Beasts - The Crime of Grindelwald",
                               "Newt Scamander is recruited by his former teacher at Hogwarts, Albus Dumbledore, to face the terrible wizard of darkness Gellert Grindelwald",
                               "https://i.pinimg.com/originals/a8/d6/af/a8d6af84671bdf315dde53cecfa14d9a.jpg",
                               "https://www.youtube.com/watch?v=8bYBOVWLNIs")

movies = [toy_story,avatar,black_swan,interestelar,baby_driver,fantastic_beasts]
fresh_tomatoes.open_movies_page(movies)
